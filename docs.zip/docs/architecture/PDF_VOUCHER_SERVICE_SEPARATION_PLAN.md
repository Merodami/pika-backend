# PDF and Voucher Service Separation Plan

## Executive Summary

This document outlines the architectural plan for separating PDF generation concerns from voucher business logic. The PDF service will consume voucher data via internal API routes to generate voucher book PDFs, maintaining clean separation of concerns.

## Architecture Overview

```
┌─────────────────────────┐     Internal API      ┌─────────────────────────┐
│    Voucher Service      │ ◄──────────────────► │      PDF Service        │
├─────────────────────────┤                       ├─────────────────────────┤
│ • Voucher CRUD          │                       │ • PDF Generation Engine │
│ • Business Logic        │                       │ • Template System       │
│ • Redemption Tracking   │                       │ • Layout Management     │
│ • QR Data Generation    │                       │ • Voucher Book Creator  │
│ • Analytics             │                       │ • Future: Invoices, etc │
└─────────────────────────┘                       └─────────────────────────┘
         │                                                    │
         ▼                                                    ▼
   Voucher Database                                    PDF Storage/Output
```

## Service Responsibilities

### Voucher Service

**Core Responsibilities:**

- Manage voucher lifecycle (creation, publishing, expiration)
- Handle redemption logic and validation
- Generate QR code data (JWT tokens)
- Manage short codes
- Track usage analytics
- Enforce business rules
- Multilingual content management
- Geolocation features

**What it DOES NOT handle:**

- PDF document generation
- Page layout concerns
- Print formatting
- Visual QR code rendering

### PDF Service

**Core Responsibilities:**

- Generate PDF documents
- Manage page layouts and templates
- Render visual QR codes from data
- Handle print specifications (bleeds, margins)
- Optimize PDFs for print/digital
- Manage fonts and assets

**What it DOES NOT handle:**

- Voucher business logic
- Redemption validation
- QR code data generation
- Voucher state management

## Internal API Communication

### 1. Service Discovery

```typescript
// Environment configuration
PDF_SERVICE_URL=http://pdf-service:5025
PDF_SERVICE_API_KEY=internal-api-key-pdf-service

VOUCHER_SERVICE_URL=http://voucher-service:5026
VOUCHER_SERVICE_API_KEY=internal-api-key-voucher-service
```

### 2. Internal Routes

#### Voucher Service Internal Routes

```typescript
// packages/services/voucher/src/routes/internal.ts

// Get vouchers for book generation
GET /internal/vouchers/for-book
Query params:
  - businessIds: string[] (comma-separated)
  - month: string (YYYY-MM)
  - status: 'active' | 'published'
  - limit: number

Response: {
  vouchers: [{
    id: string
    businessId: string
    title: { en: string, es: string, gn: string, pt: string }
    description: { en: string, es: string, gn: string, pt: string }
    terms: { en: string, es: string, gn: string, pt: string }
    discountType: 'percentage' | 'fixed'
    discountValue: number
    validFrom: Date
    validTo: Date
    qrCodeData: string  // JWT token for QR
    shortCode: string
    businessName: string
    businessLogo?: string
    category: string
  }]
}

// Validate voucher exists
GET /internal/vouchers/:id/validate
Response: {
  exists: boolean
  isActive: boolean
  businessId: string
}
```

#### PDF Service Internal Routes

```typescript
// packages/services/pdf/src/routes/internal.ts

// Generate voucher book PDF
POST /internal/pdf/voucher-book/generate
Body: {
  bookId: string
  month: string
  vouchers: VoucherData[]  // From voucher service
  adPlacements: AdPlacement[]
  metadata: {
    edition: string
    totalPages: number
    language: string
  }
}
Response: {
  pdfUrl: string
  pageCount: number
  fileSize: number
  generatedAt: Date
}

// Get generation status
GET /internal/pdf/generation/:jobId/status
Response: {
  status: 'pending' | 'processing' | 'completed' | 'failed'
  progress: number
  error?: string
}
```

### 3. Service Client Implementation

```typescript
// packages/shared/src/services/VoucherServiceClient.ts
export class VoucherServiceClient extends BaseServiceClient {
  async getVouchersForBook(params: { businessIds: string[]; month: string; status?: string }): Promise<VoucherData[]> {
    return this.get('/internal/vouchers/for-book', { params })
  }

  async validateVoucher(voucherId: string): Promise<ValidationResult> {
    return this.get(`/internal/vouchers/${voucherId}/validate`)
  }
}

// packages/shared/src/services/PDFServiceClient.ts
export class PDFServiceClient extends BaseServiceClient {
  async generateVoucherBook(data: GenerateBookRequest): Promise<GenerateBookResponse> {
    return this.post('/internal/pdf/voucher-book/generate', data)
  }

  async getGenerationStatus(jobId: string): Promise<GenerationStatus> {
    return this.get(`/internal/pdf/generation/${jobId}/status`)
  }
}
```

## Data Flow for Voucher Book Generation

```
1. Admin initiates voucher book creation
   └─> PDF Service receives request

2. PDF Service fetches voucher data
   └─> Calls Voucher Service internal API
       └─> Voucher Service returns active vouchers for specified businesses

3. PDF Service generates book
   └─> Uses voucher data to populate pages
   └─> Renders QR codes from voucher JWT data
   └─> Applies layout and ad placements

4. PDF Service returns result
   └─> Stores PDF file
   └─> Returns URL to admin
```

## Migration Plan

### Phase 1: Create Voucher Service (Week 1-2)

1. **Set up service structure**
   - Create `packages/services/voucher` following standard patterns
   - Set up database models (migrate from pika-old)
   - Implement core repositories

2. **Implement core features**
   - Voucher CRUD operations
   - State management
   - QR data generation (JWT)
   - Short code generation

3. **Create internal routes**
   - Implement `/internal/vouchers/for-book`
   - Add authentication middleware for internal calls

### Phase 2: Update PDF Service (Week 3)

1. **Remove voucher business logic**
   - Remove direct voucher database access
   - Remove voucher validation logic
   - Keep only PDF generation concerns

2. **Integrate with Voucher Service**
   - Add VoucherServiceClient
   - Update voucher book generation to fetch data
   - Modify PDF generation to use provided data

3. **Update data flow**
   - Change from direct DB queries to API calls
   - Update error handling for service communication

### Phase 3: Testing & Validation (Week 4)

1. **Integration tests**
   - Test service communication
   - Validate data contracts
   - Performance testing

2. **Migration validation**
   - Compare outputs with old system
   - Ensure no data loss
   - Verify all features work

### Phase 4: Deployment (Week 5)

1. **Staged rollout**
   - Deploy services to staging
   - Run parallel with old system
   - Monitor for issues

2. **Production deployment**
   - Deploy with feature flags
   - Gradual rollout
   - Monitor performance

## Security Considerations

### Internal API Security

1. **API Key Authentication**

   ```typescript
   // Middleware for internal routes
   export const internalAuth = (req, res, next) => {
     const apiKey = req.headers['x-api-key']
     if (apiKey !== process.env.INTERNAL_API_KEY) {
       return res.status(401).json({ error: 'Unauthorized' })
     }
     next()
   }
   ```

2. **Network Isolation**
   - Services communicate only within Docker network
   - No external access to internal routes
   - API Gateway blocks internal route patterns

3. **Rate Limiting**
   - Implement rate limits on internal routes
   - Prevent service abuse
   - Monitor unusual patterns

## Performance Optimizations

### Caching Strategy

1. **Voucher Service**
   - Cache active vouchers by business (5 min TTL)
   - Cache validation results (1 min TTL)
   - Invalidate on voucher updates

2. **PDF Service**
   - Cache generated PDFs (24 hour TTL)
   - Cache frequently used assets
   - Implement generation queue for large batches

### Batch Operations

1. **Bulk voucher fetching**
   - Support fetching multiple vouchers in one call
   - Implement pagination for large results
   - Use database query optimization

2. **Async PDF generation**
   - Queue large PDF generation jobs
   - Provide progress tracking
   - Implement retry logic

## Monitoring & Observability

### Metrics to Track

1. **Service Communication**
   - API response times
   - Error rates
   - Request volumes

2. **Business Metrics**
   - Vouchers created/redeemed
   - PDF generation success rate
   - Average generation time

### Logging

```typescript
// Standardized logging for service communication
logger.info('Fetching vouchers from voucher service', {
  service: 'pdf-service',
  action: 'fetch-vouchers',
  businessIds,
  month,
  correlationId,
})
```

## Future Enhancements

### Additional PDF Types

1. **Invoice Generation**
   - Payment Service → PDF Service
   - Generate payment receipts

2. **Report Generation**
   - Analytics Service → PDF Service
   - Business reports, user summaries

3. **Certificate Generation**
   - Achievement Service → PDF Service
   - Completion certificates

### Service Mesh Considerations

Future migration to service mesh (Istio/Linkerd) for:

- Automatic retry and circuit breaking
- Distributed tracing
- mTLS between services
- Advanced load balancing

## Success Criteria

1. **Clean Separation**
   - No voucher business logic in PDF service
   - No PDF generation logic in voucher service

2. **Performance**
   - Internal API calls < 100ms average
   - PDF generation time unchanged

3. **Reliability**
   - 99.9% uptime for both services
   - Graceful handling of service failures

4. **Maintainability**
   - Clear service boundaries
   - Easy to add new features
   - Simple debugging and monitoring

## Implementation Checklist

- [ ] Create voucher service structure
- [ ] Migrate voucher models from pika-old
- [ ] Implement voucher business logic
- [ ] Create internal API routes
- [ ] Add service authentication
- [ ] Update PDF service to use voucher API
- [ ] Remove voucher logic from PDF service
- [ ] Create comprehensive tests
- [ ] Document API contracts
- [ ] Set up monitoring
- [ ] Deploy to staging
- [ ] Validate with parallel running
- [ ] Deploy to production
- [ ] Monitor post-deployment

## Conclusion

This separation will create a more maintainable and scalable architecture where:

- Each service has a single, clear responsibility
- Services communicate through well-defined contracts
- New features can be added without affecting other services
- Testing and debugging become simpler
- System can scale independently based on load
