#!/usr/bin/env tsx

// Load environment first
import '@pika/environment'

import { UserRole, UserStatus } from '@pika/types'
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcrypt'

const prisma = new PrismaClient()

async function createTestAdmin() {
  try {
    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: 'admin-pdf-test@test.com' },
    })

    if (existingUser) {
      console.log('User already exists, updating to active status...')

      const updatedUser = await prisma.user.update({
        where: { id: existingUser.id },
        data: {
          status: UserStatus.ACTIVE,
          emailVerified: true,
          password: await bcrypt.hash('Test123!', 10),
          role: UserRole.ADMIN,
        },
      })

      console.log('✅ User updated successfully!')
      console.log('Email:', updatedUser.email)
      console.log('Status:', updatedUser.status)
      console.log('Role:', updatedUser.role)
      console.log('Password: Test123!')
    } else {
      // Create new admin user
      const hashedPassword = await bcrypt.hash('Test123!', 10)

      const user = await prisma.user.create({
        data: {
          email: 'admin-pdf-test@test.com',
          password: hashedPassword,
          firstName: 'Admin',
          lastName: 'Test',
          phoneNumber: '+1234567890123',
          role: UserRole.ADMIN,
          status: UserStatus.ACTIVE,
          emailVerified: true,
          phoneVerified: false,
          acceptTerms: true,
          marketingConsent: false,
        },
      })

      console.log('✅ Admin user created successfully!')
      console.log('Email:', user.email)
      console.log('Password: Test123!')
      console.log('Role:', user.role)
      console.log('Status:', user.status)
    }
  } catch (error) {
    console.error('❌ Error:', error)
  } finally {
    await prisma.$disconnect()
  }
}

createTestAdmin()
