#!/usr/bin/env tsx

// Load environment first
import '@pika/environment'

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function checkUserPassword() {
  try {
    const user = await prisma.user.findUnique({
      where: { email: 'admin-pdf-test@test.com' },
      select: {
        id: true,
        email: true,
        password: true,
        status: true,
        role: true,
        emailVerified: true,
      },
    })

    if (user) {
      console.log('User found:')
      console.log('ID:', user.id)
      console.log('Email:', user.email)
      console.log('Has Password:', !!user.password)
      console.log('Password Hash:', user.password)
      console.log('Status:', user.status)
      console.log('Role:', user.role)
      console.log('Email Verified:', user.emailVerified)
    } else {
      console.log('User not found')
    }
  } catch (error) {
    console.error('Error:', error)
  } finally {
    await prisma.$disconnect()
  }
}

checkUserPassword()
