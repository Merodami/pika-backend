#!/usr/bin/env tsx

import axios from 'axios'

// API Gateway URL
const API_BASE_URL = 'http://localhost:5500/api/v1'

// Test user credentials
const adminUser = {
  email: 'admin-pdf-test@test.com',
  password: 'Test123!',
  firstName: 'Admin',
  lastName: 'Test',
}

async function testPDFApi() {
  console.log('📝 Registering admin user...')

  try {
    // First, try to register the user
    try {
      const registerResponse = await axios.post(
        `${API_BASE_URL}/auth/register`,
        {
          email: adminUser.email,
          password: adminUser.password,
          firstName: adminUser.firstName,
          lastName: adminUser.lastName,
          phoneNumber: `+1${Date.now()}`,
          acceptTerms: true,
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        },
      )

      console.log('✅ User registered successfully!')
    } catch (registerError: any) {
      if (registerError.response?.status === 409) {
        console.log('ℹ️  User already exists, proceeding to login')
      } else {
        console.error('❌ Registration Error:', registerError.response?.data)
      }
    }

    console.log('\n🔐 Getting token as admin...')

    try {
      // Get token through API Gateway (OAuth 2.0 standard)
      const tokenData = {
        grantType: 'password',
        username: adminUser.email,
        password: adminUser.password,
      }

      const loginResponse = await axios.post(
        `${API_BASE_URL}/auth/token`,
        tokenData,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        },
      )

      const { accessToken } = loginResponse.data

      console.log('✅ Token obtained successfully!')
      console.log('Access Token:', accessToken)

      // Test User Admin endpoint through API Gateway
      console.log('\n👤 Testing User Admin API - GET /admin/users/me')

      try {
        const userResponse = await axios.get(`${API_BASE_URL}/admin/users/me`, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            Accept: 'application/json',
          },
        })

        console.log(
          '✅ User Admin API Response:',
          JSON.stringify(userResponse.data, null, 2),
        )
      } catch (userError: any) {
        console.error('❌ User Admin API Error:')
        console.error('Status:', userError.response?.status)
        console.error('Data:', userError.response?.data)
      }

      // Test Business Public endpoint through API Gateway
      console.log('\n🏢 Testing Business Public API - GET /businesses')

      try {
        const businessResponse = await axios.get(`${API_BASE_URL}/businesses`, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            Accept: 'application/json',
          },
        })

        console.log(
          '✅ Business API Response:',
          JSON.stringify(businessResponse.data, null, 2),
        )
      } catch (businessError: any) {
        console.error('❌ Business API Error:')
        console.error('Status:', businessError.response?.status)
        console.error('Data:', businessError.response?.data)
      }

      // Test PDF Admin endpoint through API Gateway
      console.log('\n📚 Testing PDF Admin API - GET /admin/voucher-books')

      try {
        const pdfResponse = await axios.get(
          `${API_BASE_URL}/pdf/admin/voucher-books`,
          {
            headers: {
              Authorization: `Bearer ${accessToken}`,
              Accept: 'application/json',
            },
          },
        )

        console.log(
          '✅ PDF API Response:',
          JSON.stringify(pdfResponse.data, null, 2),
        )
      } catch (pdfError: any) {
        console.error('❌ PDF API Error:')
        console.error('Status:', pdfError.response?.status)
        console.error('Data:', pdfError.response?.data)
        console.error('Headers:', pdfError.response?.headers)
      }
    } catch (loginError: any) {
      console.error('❌ Login Error:')
      console.error('Status:', loginError.response?.status)
      console.error('Data:', loginError.response?.data)
    }
  } catch (error: any) {
    console.error('❌ Unexpected Error:', error.message)
  }
}

testPDFApi()
