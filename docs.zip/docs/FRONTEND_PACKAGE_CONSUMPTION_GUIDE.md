# 📦 Frontend Package Consumption Guide

This guide explains how frontend teams can consume the published Pika packages from GitHub Packages.

## 1. **Authentication Setup**

First, the frontend team needs to authenticate with GitHub Packages:

```bash
# Create .npmrc in their project root
echo "@Merodami:registry=https://npm.pkg.github.com" >> .npmrc
echo "//npm.pkg.github.com/:_authToken=YOUR_GITHUB_TOKEN" >> .npmrc
```

**GitHub Token Requirements:**
- Token needs `read:packages` permission
- Can be Personal Access Token (classic) or fine-grained token
- Should be added to their environment or CI/CD secrets

## 2. **Package Installation**

```bash
# Install the core packages
npm install @Merodami/pika-types @Merodami/pika-api

# Or with yarn
yarn add @Merodami/pika-types @Merodami/pika-api
```

## 3. **Usage Examples**

**TypeScript Types:**
```typescript
// Import shared types
import type { 
  PaginationMetadata, 
  ApiResponse,
  ErrorResponse 
} from '@Merodami/pika-types'

// Use in your components
interface ComponentProps {
  data: ApiResponse<SomeData>
  pagination: PaginationMetadata
}
```

**API Schemas (for validation):**
```typescript
// Import Zod schemas for validation
import { 
  CreateUserRequest,
  UserResponse,
  CategoryListResponse 
} from '@Merodami/pika-api'

// Validate API responses
const validatedUser = UserResponse.parse(apiResponse)
```

## 4. **OpenAPI Specification**

The `@Merodami/pika-api` package includes the complete OpenAPI specification:

```typescript
// Access the OpenAPI spec
import { openApiSpec } from '@Merodami/pika-api'

// Generate SDK or use with tools like openapi-typescript-codegen
npx openapi-typescript-codegen \
  --input node_modules/@Merodami/pika-api/generated/openapi/all-apis.json \
  --output src/api/generated \
  --client axios
```

## 5. **Package Structure**

**@Merodami/pika-types contains:**
- Core TypeScript interfaces
- Utility types
- Shared enums
- Domain models

**@Merodami/pika-api contains:**
- Zod validation schemas
- OpenAPI specifications
- Request/Response types
- Generated documentation

## 6. **Staying Updated**

**Monitor for updates:**
```bash
# Check for new versions
npm outdated @Merodami/pika-types @Merodami/pika-api

# Update to latest
npm update @Merodami/pika-types @Merodami/pika-api
```

**CI/CD Integration:**
```yaml
# Add to their GitHub Actions
- name: Setup npm registry
  run: echo "@Merodami:registry=https://npm.pkg.github.com" >> .npmrc
  
- name: Authenticate with GitHub Packages
  run: echo "//npm.pkg.github.com/:_authToken=${{ secrets.GITHUB_TOKEN }}" >> .npmrc
```

## 7. **Publishing Schedule**

Your packages are published automatically:
- **On push to main** when API/types change
- **Manual trigger** via GitHub Actions for specific versions
- **Semantic versioning** with proper dependency updates

The frontend team should pin to specific versions in production and test updates in staging first.

## 8. **Support**

For questions or issues with package consumption:
- Check the generated OpenAPI documentation
- Review the TypeScript definitions in your IDE
- Contact the backend team for API changes or new requirements